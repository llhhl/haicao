<?php 
return [
	'seo_title'=>'[prov_or_city]微点通cms管理系统[prov_or_city]',
	'seo_keywords'=>'[prov_or_city]微点通cms管理系统[prov_or_city]',
	'seo_description'=>'[prov_or_city]微点通cms管理系统后台管理系统应用网站管理，手机网站，公众号网站等',
	'seo_cwkeyword'=>'厂家,报价,哪家好,批发x',
	'site_title'=>'微点通CMS内容管理系统',
	'site_url'=>'hcxcx.cqbcx.com',
	'site_levelurl'=>'cqbcx.com',
	'site_logo'=>'/uploads/image/20191206/fd77340f54b415d80631eb7053e2a865.png',
	'site_copyright'=>'<p>MOB：15320293856</p>
<p>版权所有 © 2019 微享科技（www.cqaaa.com）保留所有权利</p>
<p>提示说明：本网站数据只供功能演示使用，相关数据不具真实性，如需要了解微点通CMS内容管理系统的相关功能请访问微享可官网</p>',
	'site_guide'=>'0',
	'theme_style'=>'default',
	'url_model'=>'1',
	'wap_auto'=>'1',
	'wap_logo'=>'/uploads/image/20191107/3ddd31d8d0c18d27cac97cdad166fff1.png',
	'wap_copyright'=>'power by cms.cqaaa.com',
	'wap_levelurl'=>'0',
	'login_url'=>'admin.php',
	'seo_bdurl'=>'cms.400060.com',
	'seo_area'=>'0',
	'seo_title_area'=>'[prov_or_city]关键词1,[prov_or_city]关键词2,[prov_or_city]关键词3x',
	'seo_keywords_area'=>'[prov_or_city]关键词1,[prov_or_city]关键词2,[prov_or_city]关键词3x',
	'seo_description_area'=>'[prov_or_city]某某公司创立于2000年， 经过多年的不懈努力，公司现已经成为一家专业从事IT产品开发、生产和销售的高科技企业。公司成立几年来，一直致力于工控/服务器机箱及各种非标箱体的开发与生产，产品现广泛应用于计算机网络、监控、安防、广电、通讯和仪器设备等多种行业x',
	'site_protocol'=>'https',
	'site_slide'=>'0',
	'seo_default_area'=>'0',
	'qiniu'=>'0',
	'qiniu_accesskey'=>'3HmvghCkRs9vPsjAoJN5mGaNvYOf4v6SBbLHHvHI',
	'qiniu_secretkey'=>'VoCtMueejIJ9EQGkD4ETYqviMqGLR5DARL-dyBiR',
	'qiniu_bucket'=>'zxxy000001',
	'qiniu_domain'=>'http://qbdnusjef.bkt.clouddn.com/',
	'mail_smtp'=>'smtp.qq.com',
	'mail_smtpport'=>'465',
	'mail_username'=>'413274693@qq.com',
	'mail_password'=>'chfsvpjxeqlebjjc',
	'mail_setname'=>'微点通',
	'copy_sysname'=>'网站管理后台',
	'copy_name'=>'微享cms',
	'copy_url'=>'www.cqaaa.com',
	'qiniu_upurl'=>'http://up-z2.qiniup.com',
	'seo_hxkeyword'=>'核心关键词1,核心关键词2,核心关键词3x',
	'bdqc_appid'=>'',
	'bdqc_apikey'=>'',
	'bdqc_arcretkey'=>'',
	'bdqc_qcnum'=>'',
	'seo_bdurl_ziurl'=>'cms.400060.com',
	'seo_bdxzhurl'=>'cms.400060.com',
	'api_wyc'=>'0',
	'wyc_type'=>'1',
	'wyc_percent'=>'0.3',
	'wyc_appid'=>'',
	'wyc_appsecret'=>'',
	'api_bdts'=>'0',
	'api_bdxzh'=>'0',
	'api_bdqc'=>'0',
	'api_xxts'=>'0',
	'seo_bdxzhtype'=>'wap',
	'seo_ctkeyword'=>'词头1,词头2,词头3x',
	'api_pmjkhq'=>'0',
	'bdcx_url'=>'https://tongji.baidu.com/web/welcome/ico?s=beb3ed2f00ad7895e5782012f198fb22',
	'upload_file_size'=>'2004800',
	'upload_file_ext'=>'rar,zip,pdf,doc,docx,xls,xlsx,ttf,mp4',
	'upload_image_size'=>'200480',
	'upload_image_ext'=>'jpg,png,gif,ico',
	'image_watermark'=>'0',
	'image_watermark_pos'=>'9',
	'image_watermark_text'=>'测试文字',
	'image_watermark_text_size'=>'30',
	'image_watermark_text_angle'=>'0',
	'image_watermark_text_color'=>'660707',
	'image_watermark_pic'=>'/uploads/image/20191107/3ddd31d8d0c18d27cac97cdad166fff1.png',
	'image_watermark_pic_opacity'=>'50',
	'image_watermark_text_font'=>'/uploads/file/20180820/5260f3dc61b3b4e2754771fe29f614e5.ttf',
	'site_ico'=>'/favicon.ico',
	'disablewords_status'=>'1',
	'version'=>'v 1.0.1920.11.11',
	'disablewords_content'=>'最佳，更佳
最具，更具
最爱，更爱
最赚，更赚
最优，更优
最优秀，更优秀
最好，更好
最大，更大
最大程度，更大程度
最高，更高
最高级，更高级
最高端，更高端
最奢侈，更奢侈
最低，更低
最低级，更低级
最底，更底
最便宜，更便宜
史上最低价，史上更低价
最流行，更流行
最受欢迎，更受欢迎
最时尚，更时尚
最聚拢，更聚拢
最符合，更符合
最舒适，更舒适
最先，更先
最先进，更先进
最先进科学，更先进科学
最先进加工工艺，更先进加工工艺
最享受，更享受
国家级，
国家级产品，
全球级，
宇宙级，
世界级，
顶级，
顶尖，
尖端，
顶级工艺，
顶级享受，
高级，
极品，
极佳，
绝佳，
绝对，
终极，
极致，
首个，
首选，
独家，
独家配方，
首发，
全网首发，
全国首发，
首家，
全网首家，
全国首家，
首次，
首款，
全国销量冠军，
国家级产品，
国家，
国家免检，
国家领导人，
填补国内空白，
中国驰名，
驰名商标，
国家品质，
第一，
中国第一，
全网第一，
销量第一，
排名第一，
唯一，
第一品牌，
NO.1，
TOP.1，
独一无二，
全国第一，
一流，
一天，
仅此一天，
老字号，
中国驰名商标，
特供，
专供，
专家推荐，
质量免检，
无需国家质量检测，
免抽检，
国家领导人推荐，
国家机关推荐，
使用人民币图样，
史无前例，
前无古人，
永久，
万能，
祖传，
特效，
无敌，
纯天然，
100%，
高档，
正品，
真皮，
超赚，
精确，
大牌，
金牌，
名牌，
王牌，
领袖品牌，
世界领先，
遥遥领先，
领导者，
缔造者，
创领品牌，
领先上市，
巨星，
著名，
掌门人，
至尊，
巅峰，
奢侈，
优秀，
资深，
领袖，
之王，
王者，
冠军，',
	'api_mediaapikey'=>'',
	'api_media'=>'0',
	'wap_mip'=>'0',
	'admin_list_rows'=>'10',
	'mp_send'=>'1',
	'mp_appid'=>'wxa557572646b0d8e1',
	'mp_appsecret'=>'3976943c7b738fe057e32336d4969aac',
	'ali_send'=>'1',
	'ali_accesskeyid'=>'LTAIa7icwPjT8kBP',
	'ali_accesskeysecret'=>'jibZS22wlc8ly0uKaQV1DsQkK9OVhP',
	'mail_addr'=>'',
];
