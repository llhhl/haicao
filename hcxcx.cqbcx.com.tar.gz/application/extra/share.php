<?php 
return [
	'share_star'=>'1',
	'appid'=>'wxf332e034e86a5e05',
	'appsecret'=>'e1fd2e4506da7c1f4788a94c861036f8',
	'appId'=>'wxf332e034e86a5e05',
	'appSecret'=>'e1fd2e4506da7c1f4788a94c861036f8',
];
