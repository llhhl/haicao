<?php
namespace app\demo\controller;

use think\Controller;

class Index extends Controller
{
    public function index()
    {
        return "demo";
    }
}
