<?php
namespace app\demo\model;

use think\Model;

class User extends Model
{

}