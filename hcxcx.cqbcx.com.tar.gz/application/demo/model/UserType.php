<?php
namespace app\demo\model;

use think\Model;

class UserType extends Model
{

}