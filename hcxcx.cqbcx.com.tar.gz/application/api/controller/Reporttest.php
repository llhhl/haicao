<?php

echo 222;
       //上传
    public function uploadimg()
    {echo 111;
	die;
      
    }










