<?php


namespace app\index\controller;


class Upload extends Common
{

}