<?php
namespace app\model;
use think\Model;

class ReportUser extends Model
{

}
