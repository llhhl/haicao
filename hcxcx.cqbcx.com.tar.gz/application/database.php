<?php 

return [

	'type'=>'mysql',

	'hostname'=>'127.0.0.1',

	'database'=>'haicao',

	'username'=>'root',

	'password'=>'69c097130a95d47e',

	'hostport'=>'3306',

	'dsn'=>'',

	'charset'=>'utf8',

	'prefix'=>'cms_',

	'debug'=>'0',

	'deploy'=>'0',

	'rw_separate'=>'',

	'master_num'=>'1',

	'slave_no'=>'',

	'fields_strict'=>'1',

	'resultset_type'=>'array',

	'auto_timestamp'=>'',

	'datetime_format'=>'Y-m-d H:i:s',

	'sql_explain'=>'',

];

